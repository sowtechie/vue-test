<template>
 <div>
  </div> 
</template>

<script>

import './uman/uman.css';
export default {
   components: {  },
    data() {
      return {
        
        show: true
      };
    }
    
  
};
</script>