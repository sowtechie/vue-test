<template>

  </div>
</template>

<script>
import "./usearch.css";
export default {
  data() {
    return {
      headers: []

    };
  }
};
</script>